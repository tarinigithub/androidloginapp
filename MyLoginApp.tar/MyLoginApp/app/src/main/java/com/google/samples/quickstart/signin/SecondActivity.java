package com.google.samples.quickstart.signin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

public class SecondActivity extends AppCompatActivity {

    private static final String TAG = "SecondaryActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if (acct != null){

            String personName = acct.getDisplayName();
            Log.w(TAG, "Last signed-in account, personName->" + personName);
            Log.w(TAG, "Last signed-in account, getIdToken->" + acct.getIdToken());

        } else {
            Log.w(TAG, "NO ONE Has logged in ");
        }
    }
}